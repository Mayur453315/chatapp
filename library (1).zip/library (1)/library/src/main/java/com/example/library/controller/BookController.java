package com.example.library.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.library.model.Author;
import com.example.library.model.Book;
import com.example.library.service.LibraryService;

import java.util.List;

@Controller
public class BookController {

    @Autowired
    private LibraryService libraryService;

    // Display the form to add a book
    @GetMapping("/addBook")
    public String showAddBookForm(Model model) {
        model.addAttribute("book", new Book());
        return "addBook"; // Thymeleaf template for adding a new book
    }

    // Handle the form submission for adding a new book
    @PostMapping("/addBook")
    public String addBook(@ModelAttribute Book book, @RequestParam String authorName) {
        // Assuming Author is being created or fetched based on the author's name
        Author author = new Author();
        author.setName(authorName);
        libraryService.addBookAndAuthor(book, author); // Save both book and author
        return "redirect:/books"; // Redirect to the books list page after adding
    }

    // Display all books
    @GetMapping("/books")
    public String getBooks(Model model) {
        List<Book> books = libraryService.getAllBooks();
        model.addAttribute("books", books);
        return "books"; // Thymeleaf template for displaying books
    }

    // Search books by title or author
    @GetMapping("/search")
    public String searchBooks(@RequestParam String searchTerm, Model model) {
        List<Book> books = libraryService.searchBooks(searchTerm);
        model.addAttribute("books", books);
        return "books"; // Display search results on the same page as books
    }
}
