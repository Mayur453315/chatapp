package com.example.course.controller;

import com.example.course.service.CourseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/registration")
public class CourseController {

    @Autowired
    private CourseService registrationService;

    @PostMapping("/enroll")
    public String enrollStudentInCourse(@RequestParam Long studentId, @RequestParam Long courseId, Model model) {
        registrationService.enrollStudentInCourse(studentId, courseId);
        model.addAttribute("message", "Student enrolled successfully");
        return "enroll";
    }

    @PostMapping("/unenroll")
    public String unenrollStudentFromCourse(@RequestParam Long studentId, @RequestParam Long courseId) {
        registrationService.unenrollStudentFromCourse(studentId, courseId);
        return "Student unenrolled successfully";
    }

    @GetMapping("/courses/{studentId}")
    public List<?> getCoursesForStudent(@PathVariable Long studentId) {
        return registrationService.getCoursesForStudent(studentId);
    }

    @GetMapping("/students/{courseId}")
    public List<?> getStudentsInCourse(@PathVariable Long courseId) {
        return registrationService.getStudentsInCourse(courseId);
    }
    @GetMapping("/enroll")
    public String showEnrollmentForm() {
        return "enroll"; 
    }
}